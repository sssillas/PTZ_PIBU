
#include "Arduino.h"
#include "PTZProtocol.h"
#include <SoftwareSerial.h>

SoftwareSerial SerialRS = SoftwareSerial(2, 3);

/**
 * Default Constructor
 */
PTZProtocol::PTZProtocol() {
  
}

void PTZProtocol::begin(const int rxPin, const int txPin) {
  
  SerialRS.begin(9600);
}

void PTZProtocol::loop() {
 
}

void PTZProtocol::sendViscaFrame(byte *cmd, int byteSize) {
 
  //int test = sizeof(cmd);
    cmd[1] = address;
    //Serial.println(cmd)
    for (int i = 0; i < 4; i++)
  {
    SerialRS.write(PTZ_BROADCAST[i]);
  }
  delay(10);
  for (int i = 0; i < byteSize; i++)
  {
    SerialRS.write(cmd[i]);
  }
}

void PTZProtocol::changeAdress(byte *new_address) {
    address = new_address;
}
