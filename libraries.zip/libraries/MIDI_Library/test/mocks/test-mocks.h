#pragma once

#include "test-mocks_Namespace.h"

BEGIN_TEST_MOCKS_NAMESPACE

END_TEST_MOCKS_NAMESPACE
