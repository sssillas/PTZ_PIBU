
/**
 * YOUR WIRELESS NETWORK ACCESS POINT SSID AND PASSWORD
 */
#define WIFI_SSID "your_wifi_ssid_goes_here"
#define WIFI_PASS "your_wifi_password_goes_here"

/*
 * YOUR MONOCOLE GATEWAY LOCAL IP ADDRESS/HOSTNAME
 */
 #define MONOCLE_GATEWAY_ADDRESS "10.1.1.20"
 #define MONOCLE_GATEWAY_PORT     8080
