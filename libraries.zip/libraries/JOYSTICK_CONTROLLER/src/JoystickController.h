#define JOYSTICK_NOISE_GATE 16



class JoystickController
{
     private:
    /* CREATE A BOUND INSTANCE */
    /* @see: https://github.com/thomasfredericks/Bounce2 */
  
    int pan;
    int tilt;
    int zoom;

    void (*ptzCallback)(int pan, int tilt, int zoom);
     
   public:
   
    /*
     * Default Constructor
     */
     JoystickController();


     /**
      * THIS METHOD MUST BE CALLED IN THE PROGRAM MAIN LOOP
      * TO SERVICE THIS CLASS AND PROCESS THESHOLD EVALUATIONS
      * AND AXIS STATE CHANGES
      */
     void loop();

     void begin(const int pin_pan, const int pin_tilt, const int pin_zoom);

     void onPTZ(void (*ptzCallback)(int, int, int));
};

