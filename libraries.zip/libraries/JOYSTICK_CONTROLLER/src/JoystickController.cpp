
#include "Arduino.h"
#include "JoystickController.h"

struct {		  
  // Midpoints for the joystick
  uint16_t joyXMid;
  uint16_t joyYMid;
  uint16_t joyZMid;
} lastSetValues;

// Read the X position of the joystick.  The joystick already has a deadspot where it centers, but this will get rid of some of the A2D noise too
int16_t getJoyX(const int pin) {
  int16_t i = analogRead(pin) - lastSetValues.joyXMid;
  if (i<-JOYSTICK_NOISE_GATE) return i+JOYSTICK_NOISE_GATE;
  if (i>JOYSTICK_NOISE_GATE) return i-JOYSTICK_NOISE_GATE;
  return 0;
}

// Read the Y position of the joystick.  The joystick already has a deadspot where it centers, but this will get rid of some of the A2D noise too
int16_t getJoyY(const int pin) {
  int16_t i = analogRead(pin) - lastSetValues.joyYMid;
  if (i<-JOYSTICK_NOISE_GATE) return i+JOYSTICK_NOISE_GATE;
  if (i>JOYSTICK_NOISE_GATE) return i-JOYSTICK_NOISE_GATE;
  return 0;
}

int16_t getJoyZ(const int pin) {
  int16_t i = analogRead(pin) - lastSetValues.joyZMid;
  if (i<-JOYSTICK_NOISE_GATE) return i+JOYSTICK_NOISE_GATE;
  if (i>JOYSTICK_NOISE_GATE) return i-JOYSTICK_NOISE_GATE;
  return 0;
}



/**
 * Default Constructor
 */
JoystickController::JoystickController() { 

}


     /**
     * REGISTERS A CALLBACK FUNCTION POINTER FOR JOYSTICK AXIS STATE CHANGE EVENTS
     */
     void JoystickController::onPTZ(void (*ptzCallback)(int, int, int)) {
          this->ptzCallback = ptzCallback;
     }

 void JoystickController::begin(const int pin_pan, const int pin_tilt, const int  pin_zoom) {
  
    pan = pin_pan;
    tilt = pin_tilt;
    zoom = pin_zoom;

    // Get average readings for the joystick
    lastSetValues.joyXMid=0;
    lastSetValues.joyYMid=0;
    lastSetValues.joyZMid=0;
    for (uint8_t a=0; a<10; a++) {
      lastSetValues.joyXMid += analogRead(pin_pan);
      lastSetValues.joyYMid += analogRead(pin_tilt);
      lastSetValues.joyZMid += analogRead(pin_zoom);
    }
    lastSetValues.joyXMid/=10;
    lastSetValues.joyYMid/=10;
    lastSetValues.joyZMid/=10;
}

void JoystickController::loop() {
   int16_t joyX = getJoyX(pan);
  int16_t joyY = getJoyY(tilt);
  int16_t joyZ= getJoyZ(zoom);

  ptzCallback(joyX,joyY,joyZ);
  //handleJoystickPosition(joyX, joyY);
}


